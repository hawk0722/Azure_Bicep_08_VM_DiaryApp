<?php
require '../config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("INSERT INTO entries (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    header("Location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Entry</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Create New Entry</h2>
<form method="post">
    Title: <input type="text" name="title"><br>
    Content:<br>
    <textarea name="content" rows="5" cols="40"></textarea><br>
    <input type="submit" value="Save">
    <input type="button" value="Return" onclick="location.href='../index.php'">
</form>
</body>
</html>