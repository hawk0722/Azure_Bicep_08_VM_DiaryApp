<?php
$host = '<db server private ip address>'; // データベースのプライベートIPアドレス
$dbname = 'diary';
$vaultName = 'kv-diary-dev-<randomSuffix>'; // Key Vault名

function getAccessToken() {
    $url = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net";
    $headers = ["Metadata: true"];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    return $data['access_token'];
}

function getSecret($vaultName, $secretName, $accessToken) {
    $url = "https://$vaultName.vault.azure.net/secrets/$secretName?api-version=7.3";
    $headers = [
        "Authorization: Bearer $accessToken"
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    return $data['value'];
}

$accessToken = getAccessToken();
$user = getSecret($vaultName, 'db-username', $accessToken);
$password = getSecret($vaultName, 'db-password', $accessToken);

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
?>